//
//  BeaconForStoreSDK
//
//  Created by Christophe JANOT on 23/05/2014.
//  Copyright (c) 2014 Ezeeworld. All rights reserved.
//
#import "B4SApplication.h"
#import "B4SCategory.h"
#import "B4SGroup.h"
#import "B4SShop.h"
#import "B4SBeacon.h"
#import "B4SCustomerData.h"
#import "B4SInteraction.h"
#import "B4SSingleton.h"
